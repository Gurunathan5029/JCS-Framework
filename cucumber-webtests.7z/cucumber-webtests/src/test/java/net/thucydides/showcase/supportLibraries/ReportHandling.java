package net.thucydides.showcase.supportLibraries;

import java.io.IOException;

import net.thucydides.showcase.supportLibraries.ExcelHandling.status;



public interface ReportHandling {
	
public void resultstatus(String x, String y, status z) throws IOException;

}

